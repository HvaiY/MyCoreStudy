﻿namespace MyFirstABPProject
{
    public class MyFirstABPProjectConsts
    {
        public const string LocalizationSourceName = "MyFirstABPProject";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
